"""
Dspack: A Data Science Toolkit
"""
__version__ = "0.0.1"