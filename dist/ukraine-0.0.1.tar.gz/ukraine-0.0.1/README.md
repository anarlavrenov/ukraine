# Ukraine

Ukraine is a deep learning toolkit that includes transformer models, tokenizers, and masking utilities.

## Installation

```bash
pip install ukraine
